# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook shows you how to load data from transformation DB to delta lake, move the files from tiger bridge storage to temp storage using Spark SQL and python.
# MAGIC 
# MAGIC *Note*

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 1: Import libraries
# MAGIC 
# MAGIC This is a **Python** notebook so the default cell type is Python.

# COMMAND ----------

# DBTITLE 0,Import Libraries
import glob
import os
import psycopg2
import datetime
from pyspark.sql.session import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DateType

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 2: Connection properties and variables

# COMMAND ----------

# DBTITLE 0,ADF Parameters
dbutils.widgets.text("tenant_id", "desm")
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("job_type_id", "100")

dbutils.widgets.text("trans_server", "testmigration.postgres.database.usgovcloudapi.net")
dbutils.widgets.text("trans_database", "dev-desm-transformation")
dbutils.widgets.text("trans_user_name", "test@testmigration")
dbutils.widgets.text("trans_password_key", "Trans-Pass-key")
dbutils.widgets.text("trans_port", "5432")

#######################Tenant, Job and Environmnet details############################
tenantid                = dbutils.widgets.get("tenant_id")
Environment             = dbutils.widgets.get("environment")
jobtype_id              = dbutils.widgets.get("job_type_id")
#######################Transformation DB details#####################################
Trans_host              = dbutils.widgets.get("trans_server")
Trans_DB                = dbutils.widgets.get("trans_database")
Trans_DB_User           = dbutils.widgets.get("trans_user_name")
Trans_Pass_key          = dbutils.widgets.get("trans_password_key") 
#######################Key Vault details##############################################
Databricks_Scope='Azure_Keyvault'
Trans_Pass_key=dbutils.secrets.get(scope = Databricks_Scope , key =Trans_Pass_key) 
#######################Mount Point details#############################################
tb_storage_mount_loc=r'/dbfs/mnt/' + Environment + '/' + tenantid +'/' + jobtype_id + '/tb/**/*.*'
tmp_storage_mount_loc='dbfs:' + '/mnt/' + Environment + '/' + tenantid +'/' + jobtype_id + '/tb/'
#tb_storage_mount_loc='dbfs:' + '/mnt/'+Environment+'/' + tenantid +  '/temp/' 
#######################Delta Lake table details########################################


print(tenantid,Environment,jobtype_id,Trans_Pass_key)

if Environment=='prod':
    schemaName=tenantid +'_' + jobtype_id 
else:
    schemaName=tenantid
    schemaName=tenantid + '_' + Environment  +'_' + jobtype_id 
    
table1=schemaName+".stg_media_transfer_details"
table2=schemaName+".stg_media_content_type"
table3=schemaName+".stg_media_transfer_details_tmp"    
print (table1,table2,table2)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 3: Schema and spark connection details

# COMMAND ----------

# DBTITLE 0,Schema Details
def create_session():
            spark=SparkSession.builder.appName('Empty_Dataframe').getOrCreate()
            return spark
def create_df(spark,data,schema):
            df1 = spark.createDataFrame(data,schema)
            return df1

schema1 = StructType([ \
        StructField("med_seq",IntegerType(),True), \
                      StructField("media_name",StringType(),True), \
                      StructField("media_type",StringType(),True), \
                            ])
schema2 = StructType([ \
        StructField("fileextnt",StringType(),True), \
        StructField("mediatype",StringType(),True), \
        StructField("fileformat",StringType(),True), \
                     ])   
schema3 = StructType([ \
        StructField("media_name",StringType(),True), \
        StructField("media_tigerbridge_coloud_path",StringType(),True), \
                     ])  


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 4: Incremental data load 
# MAGIC 
# MAGIC Read max sequence number for Incremental load

# COMMAND ----------

try:
    Input1=spark.sql("select nvl(max(med_seq),0) from {0}.stg_media_transfer_details".format(schemaName)).collect()[0][0]
    print(Input1)
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 4"                       
    print (outputtoADF)
    dbutils.notebook.exit(return_code)    

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 5: delta lake data load 
# MAGIC 
# MAGIC Insert Media data into delta lake table - stg_media_transfer_details

# COMMAND ----------

#Input1=638
#conn = psycopg2.connect( host = Trans_host,database = Trans_DB,user = Trans_DB_User,password =Trans_Pass_key)
#cursor1=conn.cursor()
#cursor1.execute("Select med_seq,med_media_fname,'Media' Media from fb.media where med_media_fname is not null and med_seq={0} union Select med_seq,med_thumb_fname,'Thumb' from fb.media where med_thumb_fname is not null  and med_seq={0} union Select med_seq,med_meta_fname,'Meta' from fb.media where med_meta_fname is not null  and med_seq={0} union Select med_seq, concat(id,'.pdf'),'COC'  from bridge.media_mm_evidences where med_seq={0}".format(Input1)) 
#Input_data=cursor1.fetchall()
#print(Input_data)

# COMMAND ----------

# DBTITLE 0,Insert Media data into delta lake table - stg_media_transfer_details
try:
    print(Input1)
    conn = psycopg2.connect( host = Trans_host,database = Trans_DB,user = Trans_DB_User,password =Trans_Pass_key)
    cursor1=conn.cursor()

    cursor1.execute("Select med_seq,med_media_fname,'Media' Media from fb.media where med_media_fname is not null and med_seq>{0} union Select med_seq,med_thumb_fname,'Thumb' from fb.media where med_thumb_fname is not null  and med_seq>{0} union Select med_seq,med_meta_fname,'Meta' from fb.media where med_meta_fname is not null  and med_seq>{0} union Select med_seq, concat(id,'.pdf'),'COC'  from bridge.media_mm_evidences where med_seq>{0}".format(Input1)) 
    Input_data=cursor1.fetchall()
#cursor1.close()
#df=create_df(spark,Input_data,schema1)
#print(Input_data)
#table1="desm.stg_media_transfer_details"
#df.write.format("delta").mode("append").saveAsTable(table1)
#Input_data_list=[]
#for i in Input_data:
            #data=list(i)
            #Input_data_list.append(data)


    df=create_df(spark,Input_data,schema1)
    df.write.format("delta").mode("append").saveAsTable(table1)
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 5"                       
    print (outputtoADF)
    dbutils.notebook.exit(return_code)     

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 6: Update Content Type and new media name
# MAGIC 
# MAGIC Insert Content type in desm.stg_media_content_type delta lake table and update content type in - stg_media_transfer_details

# COMMAND ----------

# DBTITLE 0,Insert Content type in desm.stg_media_content_type delta lake table and update content type in - stg_media_transfer_details
try:
    spark.sql("truncate table {0}".format(table2))
    conn = psycopg2.connect( host = Trans_host,database = Trans_DB,user = Trans_DB_User,password =Trans_Pass_key)

    cursor2=conn.cursor()
    cursor2.execute("Select * from bridge.mm_file_types")

    Input_data=cursor2.fetchall()
    df=create_df(spark,Input_data,schema2)
    df.write.format("delta").mode("append").saveAsTable(table2)
    flag='Y'
    spark.sql("MERGE INTO {1}.stg_media_transfer_details USING {1}.stg_media_content_type ON substring_index({1}.stg_media_transfer_details.media_name, '.', -1) = {1}.stg_media_content_type.fileextnt and nvl({1}.stg_media_transfer_details.content_type,'ABC')='ABC' WHEN MATCHED THEN UPDATE SET content_type={1}.stg_media_content_type.mediatype".format(flag,schemaName))
    
    spark.sql("MERGE INTO {1}.stg_media_transfer_details USING {1}.STG_Evidence_ID_GEN ON {1}.stg_media_transfer_details.med_seq = {1}.STG_Evidence_ID_GEN.med_seq and  media_name_new  is null  and media_type='Media' WHEN MATCHED THEN UPDATE SET media_name_new={1}.STG_Evidence_ID_GEN.med_media_fname_guid".format(flag,schemaName))

    spark.sql("MERGE INTO {1}.stg_media_transfer_details USING {1}.STG_Evidence_ID_GEN ON {1}.stg_media_transfer_details.med_seq = {1}.STG_Evidence_ID_GEN.med_seq and  media_name_new  is null  and media_type='Meta' WHEN MATCHED THEN UPDATE SET media_name_new={1}.STG_Evidence_ID_GEN.med_meta_fname_guid".format(flag,schemaName))

    spark.sql("MERGE INTO {1}.stg_media_transfer_details USING {1}.STG_Evidence_ID_GEN ON {1}.stg_media_transfer_details.med_seq = {1}.STG_Evidence_ID_GEN.med_seq and  media_name_new  is null  and media_type='Thumb' WHEN MATCHED THEN UPDATE SET media_name_new={1}.STG_Evidence_ID_GEN.med_thumb_fname_guid".format(flag,schemaName))

    spark.sql("MERGE INTO {1}.stg_media_transfer_details USING {1}.STG_Evidence_ID_GEN ON {1}.stg_media_transfer_details.med_seq = {1}.STG_Evidence_ID_GEN.med_seq and  media_name_new  is null  and media_type='COC' WHEN MATCHED THEN UPDATE SET media_name_new={1}.STG_Evidence_ID_GEN.med_coc_fname_guid".format(flag,schemaName))
    
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 6"                       
    print (outputtoADF)
    dbutils.notebook.exit(return_code)
dbutils.notebook.exit("Pass")
    

# COMMAND ----------

# MAGIC %sql
# MAGIC Select med_seq,med_media_fname,'Media' Media from fb.media where med_media_fname is not null and med_seq>={0} union Select med_seq,med_thumb_fname,'Thumb' from fb.media where med_thumb_fname is not null  and med_seq>={0} union Select med_seq,med_meta_fname,'Meta' from fb.media where med_meta_fname is not null  and med_seq>={0} union Select med_seq, concat(id,'.pdf'),'COC'  from bridge.media_mm_evidences

# COMMAND ----------

# MAGIC %sql
# MAGIC --update desm.stg_media_transfer_details set desm.stg_media_transfer_details.media_in_tb_storage='N'
# MAGIC --update desm.stg_media_transfer_details set desm.stg_media_transfer_details.media_moved_to_temp_storage=Null;
# MAGIC --truncate table desm_dev_100.stg_media_transfer_details ;
# MAGIC --select count(*) from desm.stg_media_transfer_details order by 1
# MAGIC select * from desm_dev_100.stg_media_transfer_details   order by  1 --where media_in_tb_storage is not null

# COMMAND ----------

#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/media/2019/4/2/300001/video.mp4", "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/1@20211117215352_21280074.mp4")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/B.jpg",      "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/1@20211117215352_21280074.jpg")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/E.json",     "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/1@20211117215352_21280074.json")


#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/media/2019/4/2/300001/video.mp4", "dbfs:/mnt/dev/desm/TB/media/2021/11/17/639/1@20211117215352_21280074_000.mp4")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/B.jpg",      "dbfs:/mnt/dev/desm/TB/media/2021/11/17/639/1@20211117215352_21280074_000.jpg")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/E.json",     "dbfs:/mnt/dev/desm/TB/media/2021/11/17/639/1@20211117215352_21280074_000.json")


# COMMAND ----------

#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/media/2019/4/2/300001/flying-over-norway-4k-uhd-relaxing-music-alo.mp4", "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/c.mp4")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/media/2019/4/2/300001/flying-over-norway-4k-uhd-relaxing-music-alo.mp4", "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/d.mp4")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/media/2019/4/2/300001/flying-over-norway-4k-uhd-relaxing-music-alo.mp4", "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/e.mp4")
#dbutils.fs.cp("dbfs:/mnt/dev/desm/TB/media/2019/4/2/300001/flying-over-norway-4k-uhd-relaxing-music-alo.mp4", "dbfs:/mnt/dev/desm/TB/media/2021/11/17/638/f.mp4")

# COMMAND ----------

##%sql CREATE TABLE desm.media_transfer_details (
  #med_seq integer,
  #file_name varchar(50),
  #file_type varchar(30),
  #content_type varchar(30),
  #file_in_tb_storage char(1) DEFAULT 'N',
  #file_moved_to_temp_storage varchar(100) DEFAULT 'N',
  #file_rename_contenttype varchar(100) DEFAULT 'N',
  #file_moved_to_nexus_storage varchar(100) DEFAULT 'N'
#);

# COMMAND ----------

                     # StructField("content_type",StringType(),True), \
                     # StructField("file_in_tb_storage",StringType(),True), \
                      #StructField("file_rename_contenttype",StringType(),True), \
                      #StructField("file_moved_to_nexus_storage",StringType(),True), \
                     # StructField("tb_storage_path",StringType(),True), \
                     # StructField("temp_storage_path",StringType(),True), \

# COMMAND ----------

##%sql
#update desm.stg_media_transfer_details set desm.stg_media_transfer_details.media_in_tb_storage='N' WHERE EXISTS (SELECT 1 FROM desm.stg_media_transfer_details_tmp WHERE desm.stg_media_transfer_details.media_name= desm.stg_media_transfer_details_tmp.media_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC --MERGE INTO desm.stg_media_transfer_details USING desm.stg_media_transfer_details_tmp ON desm.stg_media_transfer_details.media_name= desm.stg_media_transfer_details_tmp.media_name  and desm.stg_media_transfer_details.media_in_tb_storage is not null  WHEN MATCHED THEN UPDATE SET media_in_tb_storage='Y',temp_storage_path='test', tb_storage_path=desm.stg_media_transfer_details_tmp.media_tigerbridge_coloud_path