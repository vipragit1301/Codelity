# Databricks notebook source
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")
dbutils.widgets.text("azure_storage_location_DB", "wasbs://databricks-deltalake@fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("azure_storage_config_DB", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("azure_storage_key", "dev-desm-storage")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("dm_tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")
Azure_Storage_Loction   = dbutils.widgets.get("azure_storage_location_DB")
Azure_Storage_Config    = dbutils.widgets.get("azure_storage_config_DB")
Azure_Sorarage_Key      = dbutils.widgets.get("azure_storage_key")

Databricks_Scope='Azure_Keyvault'


mount_point='/mnt/' + Environment + '/' + tenantid +'/' + jobtype_id + '/dl/' 

if Environment=='prod':
    schemaName=tenantid +'_' + jobtype_id 
else:
    schemaName=tenantid
    schemaName=tenantid + '_' + Environment  +'_' + jobtype_id 

try:  
        location_path  ="'" + mount_point  + schemaName + "'"       
        location_path1 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "STG_Evidence_ID_GEN'"
       
        location_path2 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "stg_media_transfer_details_tmp'"
        location_path3 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "stg_media_transfer_details'"
        location_path4 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "stg_media_content_type'"
        location_path5 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "STG_Evidence_Pdf_log_Table'"
        
        location_path6 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "STG_Evidence_Pdf_log_Table_temp'"
        
        ########print (location_path,location_path1,location_path2,location_path3)
        ############Schema and table validation Check ################################
        Input1=spark.sql("SHOW SCHEMAS").collect()       
        j=0
        data_s=[]
        print(38)
        for i in Input1:
            data1=(Input1[j][0])    
            data_s.append(data1)
            #print(data)
            j=j+1
        print(44) 
         
        ############Schema and table validation Check end ################################    
        #Step 1
        if schemaName in  data_s:
            print("Schema "+schemaName +" Already Exists")
        else:
            df = spark.sql(" CREATE SCHEMA IF NOT EXISTS  {0}  COMMENT '{0}' LOCATION {1} ".format(schemaName,location_path))
            print("Schema "+schemaName +" created")
        ##########################################################
        
        Input2=spark.sql("SHOW TABLES in {0}".format(schemaName)).collect()       
        j=0
        data_t=[]
        print(48) 
        for i in Input2:
            data2=(Input2[j][1])    
            data_t.append(data2)
            #print(data)
            j=j+1  
            
        #############################################################   
       #Step 2     
        if "stg_evidence_id_gen" in   data_t:
            print("Table stg_evidence_id_gen Already Exists")
        else:
            df1 = spark.sql("CREATE OR REPLACE TABLE {0}.STG_Evidence_ID_GEN (med_seq INT,med_media_fname STRING,med_thumb_fname STRING,med_meta_fname STRING,med_coc_fname  STRING,med_media_fname_guid STRING,med_thumb_fname_guid STRING,med_meta_fname_guid STRING,med_coc_fname_guid  STRING,batch_name  STRING) using delta location {1} ".format(schemaName,location_path1))
            
                
        print("Table stg_evidence_id_gen created ")
        #Step 3     
        if "stg_media_transfer_details_tmp" in   data_t:
            print("Table stg_media_transfer_details_tmp Already Exists")
        else:
            df2 = spark.sql("CREATE OR REPLACE TABLE {0}.stg_media_transfer_details_tmp (media_name STRING,media_tigerbridge_coloud_path STRING) using delta location {1} ".format(schemaName,location_path2))
            print("Table stg_media_transfer_details_tmp created")
        #Step 4     
        if "stg_media_transfer_details" in   data_t:
            print("Table stg_media_transfer_details Already Exists")
        else:
            df3 = spark.sql("CREATE OR REPLACE TABLE {0}.stg_media_transfer_details (med_seq INT,media_name STRING,media_name_new string,media_type STRING,content_type STRING,media_in_tb_storage STRING,media_moved_to_temp_storage STRING,media_rename STRING,media_moved_to_nexus_storage STRING,media_contenttype_metadata STRING, tb_storage_path STRING,temp_storage_path STRING,ns_storage_path STRING) using delta location {1} ".format(schemaName,location_path3))
            print("Table stg_media_transfer_details created")
        #Step 5     
        if "stg_media_content_type" in   data_t:
            print("Table stg_media_content_type Already Exists")
        else:
            df4 = spark.sql("CREATE OR REPLACE TABLE {0}.stg_media_content_type (fileextnt STRING,mediatype STRING,fileformat STRING) using delta location {1} ".format(schemaName,location_path4))  
            print("Table stg_media_content_type created")
        #Step 6     
        if "stg_evidence_pdf_log_table" in   data_t:
            print("Table stg_evidence_pdf_log_table Already Exists")
        else:
            #df5=spark.sql("CREATE OR REPLACE TABLE  {0}.STG_Evidence_Pdf_log_Table(Seq_Num INT,Des_Evidence_Id STRING,Nexus_Evidence_Id STRING,Nexus_Evidence_Id_pdf STRING,Azure_Storage_Account STRING,Azure_Container STRING,Folder STRING,Path STRING,Active_Flag STRING,Inserted_Date DATE,Tenant_ID STRING) using DELTA location {1}".format(schemaName,location_path5))
            df5=spark.sql("CREATE OR REPLACE TABLE  {0}.STG_Evidence_Pdf_log_Table(med_seq INT,evidence_id STRING,evidence_num STRING,media_coc_fname STRING,Active_Flag STRING,Inserted_Date DATE) using DELTA location {1}".format(schemaName,location_path5))
            print("Table stg_evidence_pdf_log_table created")
            df6 = spark.sql("CREATE OR REPLACE TABLE {0}.STG_Evidence_Pdf_log_Table_temp (med_seq INT,status STRING) using delta location {1} ".format(schemaName,location_path6))

        dbutils.notebook.exit("Schema Created, job Completed for "+schemaName)
except Exception as e:
    outputtoADF=f"{e}"
    return_code="FAIL"
    print(e)
    dbutils.notebook.exit(outputtoADF)

# COMMAND ----------

location_path1_1 ="'" + mount_point  + schemaName +  '/' + jobtype_id + "/" + "STG_Evidence_ID_GEN_TEMP'"
df1 = spark.sql("CREATE OR REPLACE TABLE {0}.STG_Evidence_ID_GEN_TEMP (med_seq INT,status STRING) using delta location {1} ".format(schemaName,location_path1_1))   

# COMMAND ----------

# MAGIC %sql SHOW TABLES in desm_dev_100 ---desm_100

# COMMAND ----------

# MAGIC %sql SHOW SCHEMAS

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from desm_dev.stg_media_transfer_details
# MAGIC --drop schema  desm_dev CASCADE ;
# MAGIC --drop table desm_dev.STG_Evidence_ID_GEN;
# MAGIC --drop table desm_dev.stg_media_transfer_details_tmp;
# MAGIC --drop table desm_dev.stg_media_transfer_details;
# MAGIC --drop table desm_dev.stg_media_content_type;
# MAGIC --drop table desm_dev.STG_Evidence_Pdf_log_Table

# COMMAND ----------

Input2=spark.sql("SHOW TABLES in {0}".format('desm')).collect()
list_val=[]
j=0
for i in Input2:
    data1=list(i)
    list_val.append(data1)
    
for i in list_val:
    data1=(list_val[j][1])
    print(data1)
    j=j+1

# COMMAND ----------

print(schemaName)
Input1=spark.sql("SHOW SCHEMAS").collect()
j=0
data=[]
for i in Input1:
    data1=(Input2[j][0])    
    data.append(data1)
    print(data)
    j=j+1
if schemaName in  data:
    print("Schema Exists")