# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook shows you how to create mount poitns for Tiger bridge, temp, Nexus and COC storage using Spark SQL and python.
# MAGIC 
# MAGIC *Note*

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 1: delta lake Mount

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("dm_tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")
dbutils.widgets.text("dl_azure_storage_location_DB", "wasbs://desm-dl@fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("dl_azure_storage_config_DB", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("dl_azure_storage_key", "dev-desm-storage")
dbutils.widgets.text("dl_mount_status", "Active")
dbutils.widgets.text("tb_mount_status", "Active")
dbutils.widgets.text("ns_mount_status", "Active")
dbutils.widgets.text("temp_mount_status", "Active")
dbutils.widgets.text("coc_mount_status", "Active")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("dm_tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")
Azure_Storage_Loction   = dbutils.widgets.get("dl_azure_storage_location_DB")
Azure_Storage_Config    = dbutils.widgets.get("dl_azure_storage_config_DB")
Azure_Sorarage_Key      = dbutils.widgets.get("dl_azure_storage_key")

dl_mount_status            = dbutils.widgets.get("dl_mount_status")
tb_mount_status            = dbutils.widgets.get("tb_mount_status")
ns_mount_status            = dbutils.widgets.get("ns_mount_status")
temp_mount_status          = dbutils.widgets.get("temp_mount_status")
coc_mount_status           = dbutils.widgets.get("coc_mount_status")

Databricks_Scope='Azure_Keyvault'

Local_mount_point='/mnt/' + Environment + '/' + tenantid +  '/' + jobtype_id + '/dl/'
print(Local_mount_point)

Key=dbutils.secrets.get(scope =Databricks_Scope, key = Azure_Sorarage_Key) 

try:
   #if mount_status=='Active':
        #print("Local_mount_point"," is Actvive")
    dbutils.fs.mount(source=Azure_Storage_Loction,mount_point= Local_mount_point,extra_configs={Azure_Storage_Config:Key})
except Exception as e:
                     outputtoADF=f"{e}"
                     return_code="FAIL"
                     print(outputtoADF)
                     dbutils.notebook.exit(outputtoADF)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 2: Tiger Bridge Mount

# COMMAND ----------

dbutils.widgets.text("environment", "test")
dbutils.widgets.text("dm_tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")
dbutils.widgets.text("tb_azure_storage_location_DB", "wasbs://desm-tb@fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("tb_azure_storage_config_DB", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("tb_azure_storage_key", "dev-desm-storage")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("dm_tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")
Azure_Storage_Loction   = dbutils.widgets.get("tb_azure_storage_location_DB")
Azure_Storage_Config    = dbutils.widgets.get("tb_azure_storage_config_DB")
Azure_Sorarage_Key      = dbutils.widgets.get("tb_azure_storage_key")

Databricks_Scope='Azure_Keyvault'

TB_mount_point='/mnt/' + Environment + '/' + tenantid + '/' + jobtype_id + '/tb/' 

Key=dbutils.secrets.get(scope =Databricks_Scope, key = Azure_Sorarage_Key) 

try:

        dbutils.fs.mount(source=Azure_Storage_Loction,mount_point= TB_mount_point,extra_configs={Azure_Storage_Config:Key})      

except Exception as e:
                     outputtoADF=f"{e}"
                     return_code="FAIL"
                     print(outputtoADF)
                     #dbutils.notebook.exit(outputtoADF)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 3: Nexus Mount

# COMMAND ----------

dbutils.widgets.text("environment", "test")
dbutils.widgets.text("dm_tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")
dbutils.widgets.text("ns_azure_storage_location_DB", "wasbs://desm-ns@fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("ns_azure_storage_config_DB", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("ns_azure_storage_key", "dev-desm-storage")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("dm_tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")
Azure_Storage_Loction   = dbutils.widgets.get("ns_azure_storage_location_DB")
Azure_Storage_Config    = dbutils.widgets.get("ns_azure_storage_config_DB")
Azure_Sorarage_Key      = dbutils.widgets.get("ns_azure_storage_key")

Databricks_Scope='Azure_Keyvault'

NS_mount_point='/mnt/' + Environment + '/' + tenantid + '/' + jobtype_id + '/ns/' 

Key=dbutils.secrets.get(scope =Databricks_Scope, key = Azure_Sorarage_Key) 

try:

        dbutils.fs.mount(source=Azure_Storage_Loction,mount_point= NS_mount_point,extra_configs={Azure_Storage_Config:Key})

except Exception as e:
                     outputtoADF=f"{e}"
                     return_code="FAIL"
                     dbutils.notebook.exit(outputtoADF)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 4: Temp Mount

# COMMAND ----------

dbutils.widgets.text("environment", "test")
dbutils.widgets.text("dm_tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")
dbutils.widgets.text("temp_azure_storage_location_DB", "wasbs://desm-temp@fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("temp_azure_storage_config_DB", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("temp_azure_storage_key", "dev-desm-storage")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("dm_tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")
Azure_Storage_Loction   = dbutils.widgets.get("temp_azure_storage_location_DB")
Azure_Storage_Config    = dbutils.widgets.get("temp_azure_storage_config_DB")
Azure_Sorarage_Key      = dbutils.widgets.get("temp_azure_storage_key")

Databricks_Scope='Azure_Keyvault'
 
Temp_mount_point='/mnt/' + Environment + '/' + tenantid + '/' + jobtype_id + '/temp/' 

Key=dbutils.secrets.get(scope =Databricks_Scope, key = Azure_Sorarage_Key) 

try:
        dbutils.fs.mount(source=Azure_Storage_Loction,mount_point= Temp_mount_point,extra_configs={Azure_Storage_Config:Key})
except Exception as e:
                     outputtoADF=f"{e}"
                     return_code="FAIL"
                     dbutils.notebook.exit(outputtoADF)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 5: COC Mount

# COMMAND ----------

dbutils.widgets.text("environment", "test")
dbutils.widgets.text("dm_tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")
dbutils.widgets.text("coc_azure_storage_location_DB", "wasbs://desm-coc@fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("coc_azure_storage_config_DB", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
dbutils.widgets.text("coc_azure_storage_key", "dev-desm-storage")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("dm_tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")
Azure_Storage_Loction   = dbutils.widgets.get("coc_azure_storage_location_DB")
Azure_Storage_Config    = dbutils.widgets.get("coc_azure_storage_config_DB")
Azure_Sorarage_Key      = dbutils.widgets.get("coc_azure_storage_key")

Databricks_Scope='Azure_Keyvault'
 
COC_mount_point='/mnt/' + Environment + '/' + tenantid +'/' + jobtype_id + '/coc/' 

Key=dbutils.secrets.get(scope =Databricks_Scope, key = Azure_Sorarage_Key) 

try:
        dbutils.fs.mount(source=Azure_Storage_Loction,mount_point= COC_mount_point,extra_configs={Azure_Storage_Config:Key})        
except Exception as e:
                     outputtoADF=f"{e}"
                     return_code="FAIL"
                     dbutils.notebook.exit(outputtoADF)
dbutils.notebook.exit("Storage mount point created for "+tenantid)

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.fs.unmount("/mnt/dev/desm/100/dl/")