# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook shows you how to generate guids for Media files using Spark SQL and python.
# MAGIC 
# MAGIC *Note*

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 1: Import libraries
# MAGIC 
# MAGIC This is a **Python** notebook so the default cell type is Python.

# COMMAND ----------

import hashlib
from uuid import UUID
import uuid
import psycopg2
import pandas as pd
import requests
from requests.adapters import HTTPAdapter, Retry
from pyspark.sql.session import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DateType

from datetime import date
import datetime


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 2: Connection properties and variables

# COMMAND ----------

dbutils.widgets.text("tenant_id", "desm")
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("job_type_id", "100")

dbutils.widgets.text("trans_server", "testmigration.postgres.database.usgovcloudapi.net")
dbutils.widgets.text("trans_database", "dev-desm-transformation")
dbutils.widgets.text("trans_user_name", "test@testmigration")
dbutils.widgets.text("trans_password_key", "Trans-Pass-key")
dbutils.widgets.text("trans_port", "5432")

#######################Tenant, Job and Environmnet details############################
tenantid                = dbutils.widgets.get("tenant_id")
Environment             = dbutils.widgets.get("environment")
jobtype_id              = dbutils.widgets.get("job_type_id")
#######################Transformation DB details#####################################
Trans_host              = dbutils.widgets.get("trans_server")
Trans_DB                = dbutils.widgets.get("trans_database")
Trans_DB_User           = dbutils.widgets.get("trans_user_name")
Trans_Pass_key          = dbutils.widgets.get("trans_password_key") 
Trans_db_port           = dbutils.widgets.get("trans_port")
#######################Key Vault details##############################################
Databricks_Scope='Azure_Keyvault'
Trans_Pass_key=dbutils.secrets.get(scope =Databricks_Scope, key = Trans_Pass_key) 

Batch_Name='B1'


if Environment=='prod':
    schemaName=tenantid +'_' + jobtype_id 
else:
    schemaName=tenantid
    schemaName=tenantid + '_' + Environment  +'_' + jobtype_id 
    
table1=schemaName+".STG_Evidence_ID_GEN"
table_name="bridge.media_guid_values"
server_name = "jdbc:postgresql://"
url = server_name  + Trans_host +":"+ str(Trans_db_port) +"/" + Trans_DB      
print(url)


print(table1)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 3: Schema and spark connection details

# COMMAND ----------

def create_df(spark,data,schema):
            df1 = spark.createDataFrame(data,schema)
            return df1
def create_session():
            spark=SparkSession.builder.appName('Empty_Dataframe').getOrCreate()
            return spark
evidence_schema = StructType([ \
        StructField("med_seq",IntegerType(),True), \
        StructField("med_media_fname",StringType(),True), \
        StructField("med_thumb_fname",StringType(),True), \
        StructField("med_meta_fname",StringType(),True), \
        StructField("med_coc_fname",StringType(),True), \
        StructField("med_media_fname_guid",StringType(),True), \
        StructField("med_thumb_fname_guid",StringType(),True), \
        StructField("med_meta_fname_guid",StringType(),True), \
        StructField("med_coc_fname_guid",StringType(),True), \
        StructField("batch_name",StringType(),True), \
                                     ])

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 4: GUID Generation Script

# COMMAND ----------

def convertGuidToDecimal(string1):
    if not string1:
            print("Empty string!")
    else:        
            stringToInt = string1.replace('-', '')
            stringToInt = stringToInt[::-1] 
            list1 = map(''.join, zip(*[iter(stringToInt)]*2))
            count = 0
            list2=[]    
            for l in list1:
                count+=1       
                a='0x'+(l[::-1]).lower()
                dec = int(a,0)
                list2.append(dec)          
            list2.reverse() 
            return list2
def getIdentifierFromString(stringToGenerate):
    if not stringToGenerate:
            print("Empty string!")
    else:        
        list2=[]
        count=1
        GuidVersion=5
        nameBytes= list(stringToGenerate.encode('utf-8'))        
        uuid_string = "ef6c9cdc-f091-46d2-89d3-41a5cdae58b9"
        namespaceBytes=convertGuidToDecimal(uuid_string)       
        concatinated_string= namespaceBytes + nameBytes      
        concatinatedbyteArray=bytearray(concatinated_string)        
        newgeneratedString2 = hashlib.sha1(concatinatedbyteArray)
        hash=newgeneratedString2.hexdigest()
        hash=hash.upper()       
        hashBytes=convertGuidToDecimal(hash)       
        for i in hashBytes:   
                if count<17:
                    list2.append(i)
                else:
                    break       
                count=count+1 
        ###changing 6th and 7th bit of list
        list2[6]=((list2[6] & 0x0F) | (GuidVersion << 4))
        list2[8]=((list2[8] & 0x3F) | 0x80)
        ###converting list to bytes for guid generation
        data = bytes(list2)
        ####guid generation 
        guidId=uuid.UUID(bytes=data)
        #print("guidId=\n",guidId) 
        return guidId
def insertIntoTransformationDB(df):
    try:       

        df.write \
                        .format("jdbc") \
                        .option("url", url) \
                        .option("dbtable", table_name) \
                        .option("user", Trans_DB_User) \
                        .option("password", Trans_Pass_key) \
                        .mode("append") \
                        .save()
    except (Exception) as error:
                        print(error)        

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 5: Incremental data load 
# MAGIC 
# MAGIC Read max sequence number for Incremental load

# COMMAND ----------

try:
    Input1=spark.sql("select nvl(max(med_seq),0) from {0}".format(table1)).collect()[0][0]
    print(Input1)
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 5"                       
    print (outputtoADF)
    #dbutils.notebook.exit(return_code)  

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 6: Generate GUID

# COMMAND ----------

try:        
        conn = psycopg2.connect( host = Trans_host,database = Trans_DB,user = Trans_DB_User,password =Trans_Pass_key)
        cursor1=conn.cursor()       
        cursor1.execute("Select  A.Med_Seq,med_media_fname,med_thumb_fname,med_meta_fname,B.id Eidence_ID from fb.media A left outer  join bridge.media_mm_evidences B on A.Med_Seq=B.Med_Seq  where A.Med_Seq>{0}  order by A.Med_Seq Asc ".format(Input1)) 
        Input_data=cursor1.fetchall()
       
        list3=[]     
        
        print(datetime.datetime.utcnow())
        StartTime=datetime.datetime.utcnow()
        for i in Input_data:
           
            data=list(i)
            med_seq=(data[0])
            #print("data1 med_seq",med_seq)
            med_media_fname=str(data[1])
           # print("data2 med_media_fname",med_media_fname)
            med_thumb_fname=str(data[2])
            #print("data3 med_thumb_fname",med_thumb_fname)
            med_meta_fname=str(data[3])
            #print("data4 med_meta_fname",med_meta_fname)
            med_coc_fname=str(data[4])
            med_coc_fname=(med_coc_fname + '.pdf') 
            #print("data5 med_coc_fname",med_coc_fname)
            med_media_fname_guid = getIdentifierFromString(med_media_fname) 
            med_meta_fname_guid = getIdentifierFromString(med_meta_fname)       
            med_coc_fname_guid = getIdentifierFromString(med_coc_fname)
            
            if(med_media_fname==med_thumb_fname):
                    
                    med_thumb_fname_guid=''
            else:     
                    med_thumb_fname_guid = getIdentifierFromString(med_thumb_fname)             
            
            

            data_all=[med_seq,med_media_fname,med_thumb_fname,med_meta_fname,med_coc_fname,str(med_media_fname_guid),str( med_thumb_fname_guid),str( med_meta_fname_guid),str(med_coc_fname_guid),str(Batch_Name)]
            #print(data_all)
            list3.append(data_all)      
       
        print('time taken to complete the Azure Function Execution ' + str(datetime.datetime.utcnow()- StartTime))
        StartTime2=datetime.datetime.utcnow()
        print ('writing data to DB started')
       
        
        df = create_df(spark,list3, evidence_schema)       
        
        print(table1)
        df.write.format("delta").mode("append").saveAsTable(table1)
        
        insertIntoTransformationDB(df)
        
        cursor1.close() 
        
        
        print ('writing data to DB completed')
        print('time taken to complete the data insert into Trans DB ' + str(datetime.datetime.utcnow()- StartTime2)) 
        print(datetime.datetime.utcnow())
        print('time taken to complete the job  ' + str(datetime.datetime.utcnow()- StartTime))
#create_df.head()
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 6"                       
    print (outputtoADF)
    dbutils.notebook.exit(return_code)
dbutils.notebook.exit("Pass")

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from  desm_dev_100.STG_Evidence_ID_GEN order by 1
# MAGIC --truncate  table desm_dev_100.STG_Evidence_ID_GEN 

# COMMAND ----------

# Code to read the data

driver = "org.postgresql.Driver"

database_host = "testmigration.postgres.database.usgovcloudapi.net"
database_port = "5432" # update if you use a non-default port
database_name = "dev-desm-transformation"
table = "bridge.media_guid_values"
user = "test@testmigration"
password = "Server@01"

url = f"jdbc:postgresql://{database_host}:{database_port}/{database_name}"

remote_table = (spark.read
  .format("jdbc")
  .option("driver", driver)
  .option("url", url)
  .option("dbtable", table)
  .option("user", user)
  .option("password", password)
  .load()
)


# COMMAND ----------

# Code to read the data
######################################################################################################################################################################################################################################

df.write \
    .format("jdbc") \
    .option("url", "jdbc:postgresql://testmigration.postgres.database.usgovcloudapi.net:5432/dev-desm-transformation") \
    .option("dbtable", "bridge.media_guid_values") \
    .option("user", "test@testmigration") \
    .option("password", "Server@01") \
    .mode("append") \
    .save()

# COMMAND ----------

# Code to read the data
%sql
DROP TABLE IF EXISTS jdbcTable1;
CREATE TABLE IF NOT EXISTS jdbcTable1
USING JDBC
OPTIONS (
  url "jdbc:postgresql://testmigration.postgres.database.usgovcloudapi.net:5432/dev-desm-transformation",
  dbtable "bridge.media_guid_values_3",
  user 'test@testmigration',
  password 'Server@01',
  mode "append",
  truncate "false",
  drop "false"
) AS

 SELECT * FROM desm.STG_Evidence_ID_GEN;

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC ---# Code to read the data
# MAGIC --%sql
# MAGIC DROP TABLE IF EXISTS jdbcTable1;
# MAGIC CREATE TABLE IF NOT EXISTS jdbcTable1
# MAGIC USING JDBC
# MAGIC OPTIONS (
# MAGIC   url "jdbc:postgresql://testmigration.postgres.database.usgovcloudapi.net:5432/dev-desm-transformation",
# MAGIC   dbtable "bridge.media_guid_values",
# MAGIC   user 'test@testmigration',
# MAGIC   password 'Server@01'
# MAGIC   --,mode "append",
# MAGIC   --truncate "false",
# MAGIC  -- drop "false"
# MAGIC ) ;
# MAGIC INSERT INTO jdbcTable1
# MAGIC  SELECT * FROM desm.STG_Evidence_ID_GEN;

# COMMAND ----------

# MAGIC  %sql SELECT * FROM desm_dev.STG_Evidence_ID_GEN order by 1 ;