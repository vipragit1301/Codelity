# Databricks notebook source
#pip install mysql-connector-python

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook shows you how to load data from transformation DB to delta lake, move the files from tiger bridge storage to temp storage using Spark SQL and python.
# MAGIC 
# MAGIC *Note*

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 1: Import libraries
# MAGIC 
# MAGIC This is a **Python** notebook so the default cell type is Python.

# COMMAND ----------

from datetime import date
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER, TA_RIGHT
import datetime
from pyspark.sql.session import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DateType
import pandas as pd
import mysql.connector
import psycopg2
from reportlab.platypus import ListFlowable,ListItem
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus.tables import Table,TableStyle,colors
from reportlab.platypus import Paragraph,Spacer,Frame
from reportlab.pdfgen import canvas
from reportlab.lib.styles import ParagraphStyle as PS
from reportlab.lib.pagesizes import letter, A4,portrait
from reportlab.lib.units import cm,mm
import hashlib

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 2: Connection properties and variables

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")

dbutils.widgets.text("trans_server", "testmigration.postgres.database.usgovcloudapi.net")
dbutils.widgets.text("trans_database", "dev-desm-transformation")
dbutils.widgets.text("trans_user_name", "test@testmigration")
dbutils.widgets.text("trans_password_key", "Trans-Pass-key")
dbutils.widgets.text("trans_port", "5432")

#dbutils.widgets.text("azure_storage_location", "wasbs://cocpdf@fbstorageaccount.blob.core.usgovcloudapi.net/")
#dbutils.widgets.text("azure_storage_config", "fs.azure.account.key.fbstorageaccount.blob.core.usgovcloudapi.net")
#dbutils.widgets.text("azure_storage_key", "dev-desm-storage")

Environment             = dbutils.widgets.get("environment")
tenantid                = dbutils.widgets.get("tenant_id")
jobtype_id              = dbutils.widgets.get("job_type_id")

Trans_host              = dbutils.widgets.get("trans_server")
Trans_DB                = dbutils.widgets.get("trans_database")
Trans_DB_User           = dbutils.widgets.get("trans_user_name")
Trans_Pass_key          = dbutils.widgets.get("trans_password_key")    

#Azure_Storage_Loction   = dbutils.widgets.get("azure_storage_location")
#Azure_Storage_Config    = dbutils.widgets.get("azure_storage_config")
#Azure_Sorarage_Key      = dbutils.widgets.get("azure_storage_key")
    
Databricks_Scope='Azure_Keyvault'

Trans_Pass_key=dbutils.secrets.get(scope = Databricks_Scope , key =Trans_Pass_key) 
#Azure_Sorarage_Key=dbutils.secrets.get(scope = Databricks_Scope , key =Azure_Sorarage_Key)


#Azure_Storage_Account = Azure_Storage_Loction
#Azure_Container       = Azure_Storage_Loction

if Environment=='prod':
    schemaName=tenantid +'_' + jobtype_id 
else:
    schemaName=tenantid
    schemaName=tenantid + '_' + Environment  +'_' + jobtype_id 
    
Folder=tenantid
tbl_name  = schemaName + '.STG_Evidence_Pdf_log_Table'
##tbl_name2 = schemaName + ' STG_nexus_files_COC'

coc_storage_mount_loc = '/dbfs/mnt/'+Environment+'/' + tenantid +'/' + jobtype_id +  '/coc/'
temp_storage_mount_loc = '/dbfs/mnt/'+Environment+'/' + tenantid +'/' + jobtype_id + '/temp/' 

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 3: Schema and spark connection details

# COMMAND ----------

def create_session():
            spark=SparkSession.builder.appName('Empty_Dataframe').getOrCreate()
            return spark
def create_df(spark,data,schema):
            df1 = spark.createDataFrame(data,schema)
            return df1
evidence_schema = StructType([ \
        StructField("Seq_Num",IntegerType(),True), \
        StructField("Des_Evidence_Id",StringType(),True), \
        StructField("nexus_Evidence_Id",StringType(),True), \
        StructField("Nexus_Evidence_Id_pdf", StringType(), True),\
        StructField("Azure_Storage_Account", StringType(), True), \
        StructField("Azure_Container", StringType(), True), \
        StructField("Folder", StringType(), True), \
        StructField("Path", StringType(), True), \
        StructField("Active_Flag", StringType(), True), \
        StructField("Inserted_Date", DateType(), True), \
        StructField("Tenant_ID", StringType(),True), \
                            ])
schema1 = StructType([ \
                                      StructField("med_seq",IntegerType(),True) \
                                     ])

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 4: Incremental data load 
# MAGIC 
# MAGIC Read max sequence number for Incremental load

# COMMAND ----------

try:
    Input1=spark.sql("select nvl(min(med_seq),0) from {0}.stg_media_transfer_details where media_moved_to_temp_storage is null and media_type='COC' ".format(schemaName)).collect()[0][0]
    print(Input1)
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 4"                       
    print (outputtoADF)
    dbutils.notebook.exit(return_code)   

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 5: PDF Generation funcation

# COMMAND ----------

def generatePDF():
    try:
        inserted_date = date.today()
        spark1 = create_session()
        pagesize = (20 * inch, 10 * inch)
        styles = getSampleStyleSheet()
        styleN = styles['Normal']
        width,height=A4
        #added comment
        #df1=spark.sql("truncate table {0}".format(tbl_name))
        style = ParagraphStyle(
                              name='Normal',
                              alignment=TA_RIGHT,
                              fontSize=6,
                              textColor=colors.black,
                              rightIndent=-((width/2)*0.25),)
        style2 = ParagraphStyle(
                              name='BodyText',                       
                              fontSize=6,
                              fontName='Helvetica',
                              leading = 8,
                              wordWrap='CJK',
                              textColor='blue' )
        style3 = ParagraphStyle(
                              name='BodyText',                       
                              fontSize=6,
                              fontName='Helvetica',
                              leading = 8,
                              wordWrap='CJK',
                              bulletAnchor = '-',
                              bulletType='1',
                              bulletName=u'\u25cf',
                              bulletFontSize = 10,
                              bulletColor="green",
                              bulletIndent = 18,)
        try:
            conn = psycopg2.connect(host = Trans_host,database = Trans_DB,user = Trans_DB_User,password =Trans_Pass_key)
            cursor1  = conn.cursor()
            cursor1.execute("select  med_seq from bridge.media_mm_evidences where Med_seq>={0} order by 1".format(Input1)) 
            media_seq=cursor1.fetchall()
            data_lst=[]
            df1=spark.sql("truncate table {0}.STG_Evidence_Pdf_log_Table_temp".format(schemaName))
            for i in media_seq:
                A=list(i)
                print(A[0])
                var=A[0]
                
                execution_time=str(datetime.datetime.now()) 
                data1=Paragraph(execution_time,style=style)
                elements=[]
                elements.append(data1)
                elements.append(Paragraph('Media Custody Log',styles['Title']))
                
                
                cursor1.execute("SELECT evidence_Number,evidence_category,user_Name,ID FROM bridge.media_mm_evidences where med_seq='{0}'".format(var)) 
                records=cursor1.fetchall()
                ######################print(records)
                data1=[(records[0][0],records[0][1],records[0][2])]
                ############print(data1)
                #cursor1.execute("SELECT ID FROM bridge.media_mm_evidences where med_Seq='{0}' limit 1".format(var)) 
                #Evidence_ID_1=cursor1.fetchall()
                
                pdf_file_name=records[0][3]+'.pdf'
                ##########print(pdf_file_name)
                #df=pd.DataFrame(records,columns = ['Evidence Number', 'Category', 'Author',])
                df=pd.DataFrame(data1,columns = ['Evidence Number', 'Category', 'Author',])
                pdf_table1=[df.columns.values.tolist()]+df.values.tolist()
                #############print(pdf_table1)  
                elements.append(Spacer(1,8))
                c_width1=[2.20*inch,2.20*inch,3*inch]
                data2=Table(pdf_table1,colWidths=c_width1,repeatRows=1,rowHeights = 0.2*inch)
                data2.setStyle(TableStyle([
                   ('FONTSIZE',(0,0),(-1,-1),6),
                   ('ALIGN',(0,0),(-1,-1),'LEFT'),
                    ('ALIGN',(1,0),(-1,-1),'CENTER'),
                   ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                    ('VALIGN',(0,0),(-1,0),'TOP')]))
                elements.append(data2)
                elements.append(Spacer(1, 8))
                
                
                cursor1.execute("select Act_date DATE_TIME,act_usr_Name USER_DETAILS, act_ltp_seq ACTIVITY_NUMBER,ltp_dsp_name ACTIIVTY,Act_data DETAILS,act_ip REQUEST_IP_ADDRESS  from fb.activity_log left outer join  fb.log_type on fb.activity_log.act_ltp_seq=fb.log_type.ltp_seq where act_Med_seq='{0}'order by act_med_num".format(var))
                records=cursor1.fetchall()                             
                df2=pd.DataFrame(records,columns = ['DATE_TIME','USER', 'ACTIVITY NUMBER','ACTIIVTY','DETAILS','REQUEST IP ADDRESS'])                         
                
                pdf_table2_values=df2.values.tolist()
                pdf_table2_column_values=[df2.columns.values.tolist()]
                
                tabledata1=[[Paragraph(str(x),style2) for x in row]for row in pdf_table2_column_values]
                tabledata2=[[Paragraph(str(x),style3) for x in row]for row in pdf_table2_values]
                
                t1=Table(tabledata1,colWidths=[0.8*inch, 0.8*inch, 0.8*inch, 1*inch, 3*inch, 1*inch],repeatRows=1,rowHeights = .35*inch)
               
                t2=Table(tabledata2,colWidths=[0.8*inch, 0.8*inch, 0.8*inch, 1*inch, 3*inch, 1*inch],repeatRows=1,rowHeights = 0.35*inch)
                           
                elements.append(t1)                            
                elements.append(t2)
                
                path  =coc_storage_mount_loc +pdf_file_name
                path_1=temp_storage_mount_loc+pdf_file_name
                
                document = SimpleDocTemplate(path,pagesize=A4,leftMargin=2*inch,rightMargin=2*inch)
                document.build(elements)
                
                document_1 = SimpleDocTemplate(path_1,pagesize=A4,leftMargin=2*inch,rightMargin=2*inch)
                document_1.build(elements)           
                
                
                #spark.sql("update {0}.stg_media_transfer_details set media_in_tb_storage='Y' , media_moved_to_temp_storage='Y' where med_seq='{1}'".format(schemaName,var))
                ############print("PDF file Genarted for ",var)
                
                #data1=i
                #data1=list(data1)
                #print(data1)
                #df=pd.DataFrame(i,columns = ['med_seq'])
                #df = create_df(spark,i, columns = ['med_seq'])
                #print(df)                
                #print(2)
                ##df = create_df(spark,data1, schema1)
                #df.show()                
                
                data_lst.append(i)
            tbl_name=schemaName+'.STG_Evidence_Pdf_log_Table_temp'    
            df = create_df(spark,data_lst, schema1)   
            df.write.format("delta").mode("append").saveAsTable(tbl_name)
            
            spark.sql("MERGE INTO {0}.stg_media_transfer_details USING {0}.STG_Evidence_Pdf_log_Table_temp ON {0}.stg_media_transfer_details.med_seq={0}.STG_Evidence_Pdf_log_Table_temp.med_seq and   media_type='COC' WHEN MATCHED THEN UPDATE set media_in_tb_storage='Y' , media_moved_to_temp_storage='Y'".format(schemaName))
                
            cursor1.close() 
          
        except (Exception, psycopg2.DatabaseError) as error:
            print(error)
        finally:
            if conn is not None:
                conn.close()
            #if conn1 is not None:
                #conn1.close()
        

    except Exception as e:
                     outputtoADF=f"{e}"
                     return_code="FAIL"
                     dbutils.notebook.exit(outputtoADF)   
    

generatePDF()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 6: PDF Generation

# COMMAND ----------

try:
    generatePDF()
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 6"                       
    print (outputtoADF)
    dbutils.notebook.exit(return_code)
dbutils.notebook.exit("Pass")  

# COMMAND ----------

# MAGIC %scala
# MAGIC val PATH = "dbfs:/mnt/dev/desm/100/coc/"
# MAGIC dbutils.fs.ls(PATH)
# MAGIC             .map(_.name)
# MAGIC             .foreach((file: String) => dbutils.fs.rm(PATH + file, true))

# COMMAND ----------

display(dbutils.fs.ls("/dbfs/mnt/dev/desm/100/coc/"))

# COMMAND ----------

# MAGIC %sql select nvl(min(med_seq),0) from desm_dev_100.stg_media_transfer_details where media_moved_to_temp_storage is null and media_type='COC' 

# COMMAND ----------

# MAGIC %sql ---select * from desm_dev_100.stg_evidence_id_gen_temp  order by 1   where Media_type='COC'
# MAGIC 
# MAGIC Select * from desm_dev_100.stg_media_transfer_details order by 1

# COMMAND ----------

# MAGIC %sql select * from desm_dev_100.stg_media_transfer_details order by 1;

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from desm_dev_100.stg_media_transfer_details where media_type='COC' and med_seq>719 order by 1
# MAGIC --update desm_dev_100.stg_media_transfer_details set media_in_tb_storage= null , media_moved_to_temp_storage=null where media_type='COC'

# COMMAND ----------

#data1=[(j,i,EvidencefromBridge, Nexus_id,Azure_Storage_Account,Azure_Container,Folder,my_path,'Y', inserted_date,'DESM')]
                #df3 = create_df(spark1,data1,evidence_schema)
                #tbl_name2="tenant1.STG_Evidence_Pdf_log_Table"
                #df3.write.format("delta").mode("append").saveAsTable(tbl_name)
                #print('Step248')
                #j=j+1
                #k=k+1
                 #######Insert new data in Nexus
                #id,AggregateId,AggregateName,EventType,IpAddress,EventDate,ServiceId,User,Body,CreatedAt) 
                # + Log_Value2 + Log_Value3 + Log_Value4 + Log_Value5 + Log_Value6 + Log_Value7 + Log_Value8 + Log_Value9 + Log_Value10
                
                 #cursor2_2.execute("INSERT INTO dev_desm_system_audit.logs_test VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')".format(Log_Value1,Log_Value2,Log_Value3,Log_Value4,Log_Value5,Log_Value6,Log_Value7,Log_Value8,Log_Value9,Log_Value10))
                #########Nexus_insert_stmt ="""INSERT INTO bridge.nexus_files VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) """
                #Nexus_data  = [Log_Value1,Log_Value2,Log_Value3,Log_Value4,Log_Value5,Log_Value6,Log_Value7,Log_Value8,Log_Value9,Log_Value10]
                ###########print(Log_Value1+ Log_Value2 + Log_Value3 + Log_Value4 + Log_Value5 + str(Log_Value6) + Log_Value7 + Log_Value8 + Log_Value9 +str(Log_Value10))
                #################cursor6.execute(Nexus_insert_stmt,(Log_Value1,Log_Value2,Log_Value3,Log_Value4,Log_Value5,Log_Value6,Log_Value7,Log_Value8,Log_Value9,Log_Value10))
                ######conn1.commit()

# COMMAND ----------

conn = psycopg2.connect(host = Trans_host,database = Trans_DB,user = Trans_DB_User,password =Trans_Pass_key)
cursor1  = conn.cursor()
cursor1.execute("select med_seq from bridge.media_mm_evidences where Med_seq=667 order by 1") 
media_seq=cursor1.fetchall()
for i in media_seq:
    A=list(i)
    print(A[0])
    var=A[0]
    cursor1.execute("SELECT evidence_Number,evidence_category,user_Name  FROM bridge.media_mm_evidences where med_seq='{0}'".format(var)) 
    records=cursor1.fetchall()
    print(records)
    pdf_file_name=records[0][1]+'.pdf'
    print(pdf_file_name)
    df=pd.DataFrame(records,columns = ['Evidence Number', 'Category', 'Author',])
    pdf_table1=[df.columns.values.tolist()]+df.values.tolist()
    print(pdf_table1)
    coc_storage_mount_loc='/dbfs/mnt/'+Environment+'/' + tenantid +  '/TB/' 


# COMMAND ----------

dbutils.fs.cp ("dbfs:/mnt/dev/tenant26/100/tenant26/video.mp4" ,"dbfs:/mnt/dev/tenant26/100/tenant26/video") 

# COMMAND ----------

val=101
list=[]
for i in range(0,val):
    #print(i)
    if sum(list)==50:
        list.clear()
        print("Hello")
    list.append(1)
    print(sum(list))

# COMMAND ----------

print(sum(list))