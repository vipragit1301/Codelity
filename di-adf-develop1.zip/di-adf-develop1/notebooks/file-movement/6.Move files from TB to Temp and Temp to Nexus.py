# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook shows you how to load data from transformation DB to delta lake, move the files from tiger bridge storage to temp storage using Spark SQL and python.
# MAGIC 
# MAGIC *Note*

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 1: Import libraries
# MAGIC 
# MAGIC This is a **Python** notebook so the default cell type is Python.

# COMMAND ----------

pip install azure-storage-blob

# COMMAND ----------

import glob
import os
import shutil
import psycopg2
import datetime
from pyspark.sql.session import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DateType
from azure.storage.blob import BlobServiceClient, ContentSettings
from azure.storage.blob import BlobServiceClient, ContentSettings

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 2: Connection properties and variables

# COMMAND ----------

dbutils.widgets.text("environment", "test")
dbutils.widgets.text("tenant_id", "desm")
dbutils.widgets.text("job_type_id", "100")

dbutils.widgets.text("trans_server", "testmigration.postgres.database.usgovcloudapi.net")
dbutils.widgets.text("trans_database", "dev-desm-transformation")
dbutils.widgets.text("trans_user_name", "test@testmigration")
dbutils.widgets.text("trans_password_key", "Trans-Pass-key")
dbutils.widgets.text("trans_port", "5432")

dbutils.widgets.text("ns_azure_storage_key", "dev-desm-storage")    
dbutils.widgets.text("ns_azure_storage_account", "fbstorageaccount")  
dbutils.widgets.text("ns_azure_storage_account_container", "desm-ns") 

#######################Tenant, Job and Environmnet details############################
tenantid                = dbutils.widgets.get("tenant_id")
Environment             = dbutils.widgets.get("environment")
jobtype_id              = dbutils.widgets.get("job_type_id")
#######################Transformation DB details#####################################
Trans_host              = dbutils.widgets.get("trans_server")
Trans_DB                = dbutils.widgets.get("trans_database")
Trans_DB_User           = dbutils.widgets.get("trans_user_name")
Trans_Pass_key          = dbutils.widgets.get("trans_password_key")
#######################Nexus storage details#####################################
ns_azure_storage_key    = dbutils.widgets.get("ns_azure_storage_key")
ns_azure_storage_account    = dbutils.widgets.get("ns_azure_storage_account")
ns_azure_storage_account_container    = dbutils.widgets.get("ns_azure_storage_account_container")
#######################Key Vault details##############################################
Databricks_Scope='Azure_Keyvault'
Trans_Pass_key=dbutils.secrets.get(scope = Databricks_Scope , key =Trans_Pass_key)
#######################Mount Point details#############################################
tb_storage_mount_loc=r'/dbfs/mnt/'     +Environment+'/' + tenantid +'/' + jobtype_id +'/tb/**/*.*'
tmp_storage_mount_loc='dbfs:' + '/mnt/'+Environment+'/' + tenantid +'/' + jobtype_id +  '/temp/' 
ns_storage_mount_loc='dbfs:' + '/mnt/'+Environment+'/' + tenantid  +'/' + jobtype_id+  '/ns/'

tmp_storage_mount_path='/dbfs/mnt/'+Environment+'/' + tenantid +'/' + jobtype_id +  '/temp/' 
ns_storage_mount_path='/dbfs/mnt/'+Environment+'/'  + tenantid +'/' + jobtype_id +  '/ns/' 
#######################Delta Lake table details########################################
table1=tenantid+".stg_media_transfer_details"
table2=tenantid+".stg_media_content_type"
table3=tenantid+".stg_media_transfer_details_tmp"


if Environment=='prod':
    schemaName=tenantid +'_' + jobtype_id 
else:
    schemaName=tenantid
    schemaName=tenantid + '_' + Environment  +'_' + jobtype_id 
    
    
table1=schemaName+".stg_media_transfer_details"
table2=schemaName+".stg_media_content_type"
table3=schemaName+".stg_media_transfer_details_tmp"    

 ###################Container connection=====================================
Azure_Sorarage_Key=dbutils.secrets.get(scope = Databricks_Scope , key =ns_azure_storage_key)
connect_str= "DefaultEndpointsProtocol=https;AccountName="+ns_azure_storage_account+";AccountKey="+Azure_Sorarage_Key+";EndpointSuffix=core.usgovcloudapi.net"
blob_service_client = BlobServiceClient.from_connection_string(connect_str)
dest_client         = blob_service_client.get_container_client(ns_azure_storage_account_container) 

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 3: Schema and spark connection details

# COMMAND ----------

def create_session():
            spark=SparkSession.builder.appName('Empty_Dataframe').getOrCreate()
            return spark
def create_df(spark,data,schema):
            df1 = spark.createDataFrame(data,schema)
            return df1

schema1 = StructType([ \
        StructField("med_seq",IntegerType(),True), \
                      StructField("media_name",StringType(),True), \
                      StructField("media_type",StringType(),True), \
                            ])
schema2 = StructType([ \
        StructField("fileextnt",StringType(),True), \
        StructField("mediatype",StringType(),True), \
        StructField("fileformat",StringType(),True), \
                     ])   
schema3 = StructType([ \
        StructField("media_name",StringType(),True), \
        StructField("media_tigerbridge_coloud_path",StringType(),True), \
                     ])  


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 4: Capture media files details from tiger bridge storage 
# MAGIC 
# MAGIC Read list of files and store in desm.stg_media_transfer_details_tmp and update data in  media_in_tb_storage, media_in_tb_storage and temp_storage_path columns

# COMMAND ----------

try:
    dir_path=tb_storage_mount_loc
    print(dir_path)
    data2_list =[]       
    for file in glob.glob(dir_path, recursive=True):
        data1=(os.path.basename(file).split('/')[-1])
        data2=(file.replace("/dbfs/","dbfs:/"))
    ###########File extension========================= Initaillay this was not thr======Check for performace in preprod===========
        #split_tup = os.path.splitext(data1)
        #file_extension = split_tup[1]
    #print(data1)
    #print(file_extension)
    ###########File extension=========================
        data_all=[data1,data2]
        data2_list.append(data_all)


    spark.sql("truncate table {0}".format(table3))

    df = create_df(spark,data2_list,schema3)

    df.write.format("delta").mode("append").saveAsTable(table3)

    flag="Y"

    spark.sql("MERGE INTO {1}.stg_media_transfer_details USING {1}.stg_media_transfer_details_tmp ON {1}.stg_media_transfer_details.media_name= {1}.stg_media_transfer_details_tmp.media_name and nvl({1}.stg_media_transfer_details.media_in_tb_storage,'ABC')<>'{0}' WHEN MATCHED THEN UPDATE SET media_in_tb_storage='{0}',temp_storage_path='{2}', tb_storage_path={1}.stg_media_transfer_details_tmp.media_tigerbridge_coloud_path".format(flag,schemaName,tmp_storage_mount_loc))
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 7"                       
    print (outputtoADF)
    #dbutils.notebook.exit(return_code)     

# COMMAND ----------

# MAGIC %sql ---select * from desm_dev_100.stg_evidence_id_gen_temp  order by 1   where Media_type='COC'
# MAGIC 
# MAGIC Select * from desm_dev_100.stg_media_transfer_details order by 1

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 5: Move files from tiger bridge to temp storage
# MAGIC 
# MAGIC Move files from tiger bridge storage to temp storage and lod the status in desm.stg_media_transfer_details

# COMMAND ----------


try:
    Input2=spark.sql("select media_name,tb_storage_path,temp_storage_path from {0}.stg_media_transfer_details where media_in_tb_storage='Y' and media_moved_to_temp_storage is null  order by 1".format(schemaName)).collect()
    list_val=[]
    j=0
    for i in Input2:
        #data1=str(i[0][1])
        data1=list(i)
        list_val.append(data1)
        ###print(i)
    for i in  list_val:
        data2=(list_val[j][0])
        data3=(list_val[j][1])
        data4=(list_val[j][2])
        #print((data2,data3,data4))
        #dbutils.fs.cp(data3,data4)
        ##############eleiminate dbutils and use shutil==================================
        data3=data3.replace("dbfs:/","/dbfs/")
        data4=data4.replace("dbfs:/","/dbfs/")
        print((data2,data3,data4))
        shutil.copy(data3,data4)
        ##############eleiminate dbutils and use shutil==================================
        spark.sql("update {0}.stg_media_transfer_details set media_moved_to_temp_storage='Y' where media_name='{1}'".format(schemaName,data2))        
        j=j+1
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 8"                       
    print (e)
    dbutils.notebook.exit(return_code)             
    
#dbutils.notebook.exit("Pass")
    

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Step 6: Rename files in temp storage and move nexus storage
# MAGIC 
# MAGIC Move files from tiger bridge storage to temp storage and lod the status in desm.stg_media_transfer_details

# COMMAND ----------

try:
 
    
    Input3=spark.sql("select media_name,media_name_new,content_type from {0}.stg_media_transfer_details where media_moved_to_temp_storage='Y' and media_rename is null  order by 1".format(schemaName)).collect()
    list_val1=[]
    j=0
    for i in Input3:
        data1=list(i)
        list_val1.append(data1)
        #print(i)
    print("step11")    
    for i in  Input3:
        rn_data=(Input3[j][0])
        ne_data=(Input3[j][1])
        Content_type=(Input3[j][2])
        print("step16",tmp_storage_mount_path,Input3[j][0])
        print("step16",tmp_storage_mount_path,Input3[j][1])
        old_name=tmp_storage_mount_path+(Input3[j][0])
        new_name=tmp_storage_mount_path+(Input3[j][1])
        print(old_name,new_name)
        print("step19")
        os.rename(old_name, new_name)
        spark.sql("update {0}.stg_media_transfer_details set media_rename='Y' where media_name='{1}'".format(schemaName,rn_data))
        
        
        temp_path=tmp_storage_mount_path+(Input3[j][1])
        ns_path  =ns_storage_mount_path +(Input3[j][1])
        print(temp_path,ns_path)
        shutil.copy(temp_path,ns_path)
        spark.sql("update {0}.stg_media_transfer_details set media_moved_to_nexus_storage='Y' where media_name='{1}'".format(schemaName,rn_data))
        print("step29")
        blobs = dest_client.list_blobs(ne_data)
        for blob in blobs:
            #print(blob)
            file_name=blob.name
            print(file_name)
            if file_name==ne_data:
                filetype=Content_type
                cnt_settings = ContentSettings(content_type=filetype)
                destclient = dest_client.get_blob_client(blob)
                destclient.set_http_headers(content_settings=cnt_settings)
                destclient.set_blob_metadata(metadata={'CopyComplete': 'true'})
                
                spark.sql("update {0}.stg_media_transfer_details set media_contenttype_metadata='Y' where media_name='{1}'".format(schemaName,rn_data))
        
        j=j+1
except Exception as e:
    outputtoADF=f"{e}"
    return_code="Fail at Step 6"                       
    print (e)
    #dbutils.notebook.exit(return_code)   

# COMMAND ----------

dbutils.notebook.exit("Pass")

# COMMAND ----------

# MAGIC %sql
# MAGIC update desm.stg_media_transfer_details set desm.stg_media_transfer_details.media_rename=Null;
# MAGIC update desm.stg_media_transfer_details set desm.stg_media_transfer_details.media_moved_to_temp_storage=Null;

# COMMAND ----------

# MAGIC %sql select * from desm_dev_100.stg_media_transfer_details order by 1;

# COMMAND ----------

dbutils.fs.rm("dbfs:/mnt/dev/desm/100/temp/",recurse=True)

# COMMAND ----------

# MAGIC %scala
# MAGIC val PATH = "dbfs:/mnt/dev/desm/100/ns/"
# MAGIC dbutils.fs.ls(PATH)
# MAGIC             .map(_.name)
# MAGIC             .foreach((file: String) => dbutils.fs.rm(PATH + file, true))