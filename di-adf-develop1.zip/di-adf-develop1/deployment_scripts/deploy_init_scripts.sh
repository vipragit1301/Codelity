#!/bin/bash


workspaceUrl="https://adb-5102355298060021.1.databricks.azure.us"   
databricks_token="dapicf5900646cc205c56740a95fa9fc7f99"  
initScriptsPath="dbfs:/tmp/init-scripts"
# Create directory for Init Scripts


JSON="{ \"path\" : \"$initScriptsPath\" }"


echo "curl $workspaceUrl/api/2.0/dbfs/mkdirs -d $JSON"





curl  -X POST $workspaceUrl/api/2.0/dbfs/mkdirs \
-H "Authorization:Bearer $databricks_token" \
-H 'Content-Type: application/json' -d '{"path": "dbfs:/tmp/init-scripts"}'

#curl -X GET $workspaceUrl/api/2.0/dbfs/list \
    #-H "Authorization:Bearer $databricks_token" \
   
   # -H 'Content-Type: application/json' -d '{"path": "dbfs:/tmp/"}'

echo "curl https://adb-5102355298060021.1.databricks.azure.us/api/2.0/libraries/install"
curl  -X POST https://adb-5102355298060021.1.databricks.azure.us/api/2.0/libraries/install \
-H "Authorization:Bearer $databricks_token" \
-H 'Content-Type: application/json' -d '{ "cluster_id": "1205-121057-icnjppnl",
    "libraries": [
     
      
      {
        "pypi": {
          "package": "azure-storage-blob",
          "repo": "https://my-pypi-mirror.com"
        }
      }
      
    ]}'


 

 







