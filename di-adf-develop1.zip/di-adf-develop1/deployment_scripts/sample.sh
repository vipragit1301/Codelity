#!/bin/bash
pip install azure-storage-blob
