#!/bin/bash
workspaceUrl="https://adb-5102355298060021.1.databricks.azure.us"   
databricks_token="dapicf5900646cc205c56740a95fa9fc7f99"  

echo "Databricks workspaceUrl: $workspaceUrl"
notebookPathUnderWorkspace='/deploy_notebooks'


#managementToken=$(curl -X POST https://login.microsoftonline.us/$tenant_id/oauth2/token \
  #-F resource=https://management.core.windows.net/ \
  #-F client_id=$client_id \
 # -F grant_type=client_credentials \
  #-F client_secret=$client_secret | jq .access_token --raw-output) 



# Get Databricks workspace URL 

#workspaceUrl=$(curl -X GET \
       # -H "Content-Type: application/json" \
       # -H "Authorization: Bearer $managementToken" \
       # https://management.azure.com/subscriptions/$subscription_id/resourcegroups/$resourceGroup/providers/Microsoft.Databricks/workspaces/$workspaceName?api-version=2018-04-01 \
       # | jq .properties.workspaceUrl --raw-output)

#echo "Databricks workspaceUrl: $workspaceUrl"

# Create directory Paths 

replaceSource="./"
replaceDest=""

find ./notebooks/ -type d -name "file-movement" -print0 | while IFS= read -r -d '' dirPath; do
    echo "Processing directory path is given as: $dirPath"
    
    #directoryName=${dirPath//$replaceSource/$replaceDest}
    #echo "New directoryName: $directoryName"

    # if [[ "$dirPath" = "." ]];
   # then
       # pathOnDatabricks=$notebookPathUnderWorkspace
    #else
        #pathOnDatabricks="$notebookPathUnderWorkspace/$directoryName"
    #fi
    #echo "pathOnDatabricks: $pathOnDatabricks"

   

   
done


# Deploy notebooks 

    find $dirPath -type f -name "*.py" -print0 | while IFS= read -r -d '' file; do
        echo "Processing file: $file"
        filename=${file//$replaceSource/$replaceDest}
        echo "New filename: $filename"

        language=""
        if [[ "$filename" == *sql ]]
        then
            language="SQL"
        fi

        if [[ "$filename" == *scala ]]
        then
            language="SCALA"
        fi

        if [[ "$filename" == *py ]]
        then
            language="PYTHON"
        fi

        if [[ "$filename" == *r ]]
        then
            language="R"
        fi

        echo "curl -F language=$language -F path=$notebookPathUnderWorkspace/$filename -F content=@$file $workspaceUrl/api/2.0/workspace/import"

        
        
        curl -n $workspaceUrl/api/2.0/workspace/import \
            -H "Authorization:Bearer $databricks_token" \
            -F language="$language" \
            -F overwrite=true \
            -F path="$notebookPathUnderWorkspace/$filename" \
            -F content=@"$file"       

        echo ""          

    done

